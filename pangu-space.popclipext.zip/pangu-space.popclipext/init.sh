#!/bin/sh
~/.pyenv/shims/python3 pangu-space.py

